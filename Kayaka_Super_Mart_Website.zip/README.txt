KAYAKA SUPER MART WEBSITE
==========================

Files:
- index.html  : Main website
- style.css   : Website styling

The website is already configured with:
- Kayaka Super Mart
- 189, Housing Board Colony, Ambika Nagar, Kalaburagi, Karnataka 585102
- 10:00 AM to 9:30 PM
- Phone/WhatsApp: 9449291427
- WhatsApp ordering links
- Google Maps directions link

To preview:
1. Keep index.html and style.css in the same folder.
2. Open index.html in a web browser.

To publish it online:
Upload both files to a web-hosting service or connect them to a domain.
